let data = [
    {
        Charge: "免費",
        name: "廖洧杰充電站"
    },
    {
        Charge: "投幣式",
        name: "小花充電站"
    },
    {
        Charge: "投幣式",
        name: "小明充電站"
    },
    {
        Charge: "投幣式",
        name: "小天充電站"
    }
];

//初始化資料，把資料庫的東西呈現到網頁
const list = document.querySelector(`.lsit`);
console.log(list);